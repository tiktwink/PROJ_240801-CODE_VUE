import{av as e,aA as a,aB as c}from"./index-4Bm1Eb5i.js";const r={name:"Teacher"};function t(o,n,s,p,_,f){return a(),c("div")}const i=e(r,[["render",t]]);export{i as default};
