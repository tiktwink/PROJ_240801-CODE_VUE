import{av as t,aA as e,aB as a}from"./index-4Bm1Eb5i.js";const r={name:"History",data(){return{}}};function o(s,n,c,p,_,i){return e(),a("div")}const f=t(r,[["render",o]]);export{f as default};
