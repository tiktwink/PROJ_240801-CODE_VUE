import{av as a,aA as e,aB as s}from"./index-4Bm1Eb5i.js";const t={name:"Class"};function n(o,c,r,l,p,_){return e(),s("div",null,"这里是班级管理")}const d=a(t,[["render",n]]);export{d as default};
